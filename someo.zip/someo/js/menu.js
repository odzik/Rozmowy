$(document).ready(function(){
	
	$("#pasek").on("click", function() {
		if( $("#pojemnik_menu").css('display')== 'none')
			$("#pojemnik_menu").stop().fadeIn(150);
		else
			$("#pojemnik_menu").stop().fadeOut(150);
	});
	
	$("#pasek2").on("click", function() {
		if( $(".filters").css('display')== 'none')
			$(".filters").stop().fadeIn(150);
		else
			$(".filters").stop().fadeOut(150);
	});
	
	$( "#pojemnik_menu_rozwijane" ).hover(function() {
		  $( "#pojemnik_menu_rozwijane .submenu" ).stop().fadeIn(150);
	}).mouseleave(function(){
		$( "#pojemnik_menu_rozwijane ul:nth-child(2) .submenu" ).stop().fadeOut(150);	
	});
	
	$( "#pojemnik_menu_rozwijane2" ).hover(function() {
		  $( "#pojemnik_menu_rozwijane2 .submenu" ).stop().fadeIn(150);
	}).mouseleave(function(){
		$( "#pojemnik_menu_rozwijane2 ul:nth-child(2) .submenu" ).stop().fadeOut(150);	
	});
	
	$( "#pojemnik_menu_rozwijane3" ).hover(function() {
		  $( "#pojemnik_menu_rozwijane3 .submenu" ).stop().fadeIn(150);
	}).mouseleave(function(){
		$( "#pojemnik_menu_rozwijane3 ul:nth-child(2) .submenu" ).stop().fadeOut(150);	
	});
	
	$( "#pojemnik_menu_rozwijane4" ).hover(function() {
		  $( "#pojemnik_menu_rozwijane4 .submenu" ).stop().fadeIn(150);
	}).mouseleave(function(){
		$( "#pojemnik_menu_rozwijane4 ul:nth-child(2) .submenu" ).stop().fadeOut(150);	
	});
	
	$( "#pojemnik_menu_rozwijane5" ).hover(function() {
		  $( "#pojemnik_menu_rozwijane5 .submenu" ).stop().fadeIn(150);
	}).mouseleave(function(){
		$( "#pojemnik_menu_rozwijane5 ul:nth-child(2) .submenu" ).stop().fadeOut(150);	
	});
});

