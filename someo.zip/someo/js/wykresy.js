function czas() {
    var liczba = document.getElementById("liczba").value;
    if(liczba > 0) {
        document.getElementById("charts").innerHTML="Dodatnia";
        
        else if(liczba < 0 )
        document.getElementById("charts").innerHTML = "Ujemna";
    
        else if(liczba == "")
        document.getElementById("charts").innerHTML = "To pole jest puste";
    
        else if(liczba == 0)
        document.getElementById("charts").innerHTML = "Zero";
    
        else
        document.getElementById("charts").innerHTML = "Wartość nie jest liczba";
    }
    }