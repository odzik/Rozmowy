$(document).ready(function (){
	$( "#zaloguj" ).on( "click", function() {
		var przeslij = $.post( "../someo/php/logowanie.php", { login: $("#login").val(), haslo: $("#password").val() })
		przeslij.done(function(data) {
			if (data == 1)
			{
				window.location.href = '../someo/main.php';
			}
			else
			{
				$("#komunikat").html("Nie udało się zalogować, wprowadź poprawne dane");
			}
		 });
		przeslij.fail(function() {
			 alert( "Bład " + data );
		 });
		return false;
	});
});