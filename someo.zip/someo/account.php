<!DOCTYPE html>

<?php
	session_start();
?>
<html>

    <head>
        <meta charset="utf-8">
		<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
        <title>Kontrola produkcji - Lakiernia</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>SZYBKI START Z BRACKETS</title>
        <link rel="stylesheet" href="bootstrap-4.0.0/dist/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js">
		
        <link rel="stylesheet" href="css/account.css?1">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Dosis&display=swap" rel="stylesheet">
        <link rel="shortcut icon" href="grafika/logo2.png">
        <link rel="stylesheet" type="text/css" href="js/jquery.jqplot.css" />
<!--[if IE]><script language="javascript" type="text/javascript" src="js/excanvas.js"></script><![endif]-->
<script language="javascript" type="text/javascript" src="js/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="js/jquery.jqplot.min.css"></script>
<script language="javascript" type="text/javascript" src="js/jqplot.logAxisRenderer.js"></script>
<script language="javascript" type="text/javascript" src="js/menu.js"></script>
    </head>
    <body >
		<div id="pojemnik_menu">
			<div id="pojemnik_logo">
				<ul>
					<li class="logo"><a href="index.html"><img src=grafika/logo.png></a></li>
				</ul>
			</div>
			<div id="pojemnik_kafelki">
				<ul>
					<li class="submenu"><a href="index.html"><span>Overview</span></a></li>
				</ul>
				<div id="pojemnik_menu_rozwijane">
					<ul>
						<li class="submenu"><a href="index.html"><span>Control of Production</span></a></li>
					</ul>
					<ul>
							<li class="submenu"><a href="index.html"><span>Production plan</span></a></li>
							<li class="submenu"><a href="index.html"><span>Production</span></a></li>
							<li class="submenu"><a href="index.html"><span>Product list</span></a></li>
							<li class="submenu"><a href="index.html"><span>BOM List</span></a></li>
							<li class="submenu"><a href="index.html"><span>Route List</span></a></li>							
							<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
					</ul>
				</div>
				<div id="pojemnik_menu_rozwijane2">
					<ul>
						<li class="submenu"><a href="index.html"><span>Quality</span></a></li>
					</ul>
					<ul>
							<li class="submenu"><a href="index.html"><span>Visual Control</span></a></li>
							<li class="submenu"><a href="index.html"><span>SPC</span></a></li>
							<li class="submenu"><a href="index.html"><span>Documentation</span></a></li>
							<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
					</ul>
				</div>
				<div id="pojemnik_menu_rozwijane3">
					<ul>
						<li class="submenu"><a href="index.html"><span>Organization</span></a></li>
					</ul>
					<ul>
							<li class="submenu"><a href="index.html"><span>Organization Chart</span></a></li>
							<li class="submenu"><a href="index.html"><span>Human Resources</span></a></li>
							<li class="submenu"><a href="index.html"><span>Procedures</span></a></li>
							<li class="submenu"><a href="index.html"><span>Forms</span></a></li>
							<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
					</ul>
				</div>
				<div id="pojemnik_menu_rozwijane4">
					<ul>
						<li class="submenu"><a href="index.html"><span>Purchasing & Warehouse</span></a></li>
					</ul>
					<ul>
							<li class="submenu"><a href="index.html"><span>Budget list</span></a></li>
							<li class="submenu"><a href="index.html"><span>Material Warehouse</span></a></li>
							<li class="submenu"><a href="index.html"><span>Supportly Warehouse</span></a></li>
							<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
					</ul>
				</div>
				
				<div id="pojemnik_menu_rozwijane5">
					<ul>
						<li class="submenu"><a href="index.html"><span>System</span></a></li>
					</ul>
					<ul>
							<li class="submenu"><a href="account.php"><span>Account</span></a></li>
							<li class="submenu"><a href="admin.html"><span>Administration</span></a></li>
							<li class="submenu"><a href="index.html"><span>Log out</span></a></li>
					</ul>
				</div>
			</div>
		</div>
            <div class="pasek"></div>
	<!-- 		<div class="account_information">
				<?php 
				$login = $_SESSION['login'];
				$email = $_SESSION['email'];
				$uprawnienia = $_SESSION['uprawniania'];
				$stanowisko = $_SESSION['stanowisko'];
				$nr_pracownika = $_SESSION['nr_pracownika'];
				$dzial = $_SESSION['dzial'];
				echo<<<END
				<div id="container_account_information">
				<span>Login:$login</span><div class="pasek_pion"></div>
				<span>E-mail: $email</span><div class="pasek_pion"></div>
				<span>Uprawnienia: $uprawnienia</span><div class="pasek_pion"></div>
				<span>Stanowisko: $stanowisko</span><div class="pasek_pion"></div>
				<span>Nr. Pracownika:$nr_pracownika</span><div class="pasek_pion"></div>
				<span>Dział: $dzial</span>>
				</div>
END;
				?>
			</div> -->
			<div id="pojemnik_na_informacje_o_koncie">
				<div class="container mt-5 mb-5">
					<div class="row no-gutters">
						<div class="col-md-4 col-lg-4"><img src="https://i.imgur.com/aCwpF7V.jpg"></div>
						<div class="col-md-8 col-lg-8">
							<div class="d-flex flex-column">
								<div class="d-flex flex-row justify-content-between align-items-center p-5 bg-dark text-white">
									<h3 class="display-5"><?php mb_internal_encoding('UTF-8');mb_http_output('UTF-8'); echo $_SESSION['imie']." ".$_SESSION['nazwisko'];?></h3><i class="fa fa-facebook"></i><i class="fa fa-google"></i><i class="fa fa-youtube-play"></i><i class="fa fa-dribbble"></i><i class="fa fa-linkedin"></i>
								</div>
								<div class="p-3 bg-black text-white">
									<h6><?php echo $_SESSION['stanowisko'];?></h6>
								</div>
								<div class="d-flex flex-row text-white">
									<div class="p-4 bg-primary text-center skill-block">
										<h4>Pracownik</h4>
										<h6>555</h6>
									</div>
									<div class="p-3 bg-success text-center skill-block">
										<h4>Urlop</h4>
										<h6>15</h6>
									</div>
									<div class="p-3 bg-warning text-center skill-block">
										<h4>Department</h4>
										<h6>Varnishing & Tampoprint</h6>
									</div>
									<div class="p-3 bg-danger text-center skill-block">
										<h4>75%</h4>
										<h6>PHP</h6>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
		</div>
           <!--  <div id="wynik">
                <table class=" table table-striped table-dark overview">
                        <tr>
                            <th scope="col">OEE: </th>
                            <th id="%oee"scope="col">78%</th>
                            <th scope="col">Quality: </th>
                            <th id="%quality" scope="col">85%</th>
                            <th scope="col">Plan realization: </th>
                            <th id="%planrealization" scope="col">95%</th>
                            <th scope="col">Monthly scrap cost: </th>
                            <th id="%planrealization" scope="col">32000PLN</th>
                        </tr>
                </table>
                <div class="pasek"></div>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Systems</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Waterborn</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>HG</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Matt</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Metalic</th>
                                <th>%</th>
                        </tr>
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Clients</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>BHTC</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Denso</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>MAN</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Seuffer</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>HG</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>MAT</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>BHTC</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>MAN</th>
                                <th>%</th>
                        </tr>
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Metalic</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Seuffer</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Denso</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        <input type="text" id="liczba" />
        <input type="submit" value="sprawdz" onclick="czas()"/>
       <div id="charts"></div>
	  -->
    </body>
</html>
