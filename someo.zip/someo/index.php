<!DOCTYPE html>
<html lang="pl">

    <head>
        <meta charset="utf-8">
        <title>Kontrola produkcji - Lakiernia</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>SZYBKI START Z BRACKETS</title>
        <link rel="stylesheet" href="bootstrap-4.0.0/dist/css/bootstrap.css">
        <link rel="stylesheet" href="bootstrap-4.0.0/dist/css/bootstrap.min.css" id="bootstrap-css">
        <link rel="stylesheet" href="css/logowanie.css?1">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Dosis&display=swap" rel="stylesheet">
        <link rel="shortcut icon" href="grafika/logo2.png">
        <link rel="stylesheet" type="text/css" href="js/jquery.jqplot.css" />
<!--[if IE]><script language="javascript" type="text/javascript" src="js/excanvas.js"></script><![endif]-->
    <script language="javascript" type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jquery.jqplot.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/jqplot.logAxisRenderer.js"></script>
    <script language="javascript" type="text/javascript" src="bootstrap-4.0.0/dist/js/bootstrap.min.js"></script>
    <script language="javascript" type="text/javascript" src="js/logowanie.js"></script>
        
    </head>
    <body >
        <div id="logo"></div>
        <div class="wrapper fadeInDown">
          <div id="formContent">
            <!-- Tabs Titles -->

            <!-- Icon -->
            <div class="fadeIn first">
              <img src="grafika/logo.png" id="icon" alt="User Icon" />
            </div>

            <!-- Login Form -->
            <form method="post" role="form" enctype="application/x-www-form-urlencoded">
              <input type="text" id="login" class="fadeIn second" name="login" placeholder="login">
              <input type="password" id="password" class="fadeIn third" name="haslo" placeholder="password">
              <input id="zaloguj" type="submit" class="fadeIn fourth" value="Log In">
            </form>
			
			<div id="komunikat"></div>

            <!-- Remind Passowrd -->
            <div id="formFooter">
              <a class="underlineHover" href="#">Forgot Password?</a>
            </div>

          </div>
        </div>
    </body>
</html>
