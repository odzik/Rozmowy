<?php 
session_start();
require_once "connect.php";
mb_internal_encoding('UTF-8');
mb_http_output('UTF-8');
$polaczenie = @new mysqli($host, $logindb, $haslodb, $dbname);
$polaczenie->set_charset("utf8mb4");
if ($polaczenie->connect_errno!=0)
{
	echo<<<END
	
	<script type="text/javascript">
	alert("Error: ".'$polaczenie->connect_errno.'" Opis: ".'$polaczenie->connect_error');
	
	</script>
END;
}
else
{	
	$login = $_POST['login'];
	$haslo = $_POST['haslo'];
	
	$login = htmlentities($login, ENT_QUOTES, "UTF-8");
	$haslo = htmlentities($haslo, ENT_QUOTES, "UTF-8");

	if ($rezultat = @$polaczenie->query(
	sprintf("SELECT * FROM uzytkownicy WHERE login='%s' AND haslo='%s'",
	mysqli_real_escape_string($polaczenie, $login),
	mysqli_real_escape_string($polaczenie, $haslo))))
	{
		$ile_rekordow = $rezultat->num_rows;
		if ($ile_rekordow > 0)
		{
			$wierszy = $rezultat->fetch_assoc();
			$_SESSION['login'] = $wierszy['login'];
			$_SESSION['email'] = $wierszy['email'];
			$_SESSION['imie'] = $wierszy['imie'];
			$_SESSION['nazwisko'] = $wierszy['nazwisko'];
			$_SESSION['uprawniania'] = $wierszy['uprawnienia'];
			$_SESSION['stanowisko'] = $wierszy['stanowisko'];
			$_SESSION['nr_pracownika'] = $wierszy['nr_pracownika'];
			$_SESSION['dzial'] = $wierszy['dzial'];
			echo $ile_rekordow;
			$rezultat->close();
		}
		else
		{
			echo 'Bład połączenia z serwerem.';
		}
	}
	ELSE
	{
		echo $ile_rekordow;
	}	


	$polaczenie->close();
}
?>