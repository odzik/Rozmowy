<?php 

	$host = "localhost";
	$logindb = "root";
	$haslodb = "";
	$dbname = "uzytkownicy";

?>