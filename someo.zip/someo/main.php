<!DOCTYPE html>

<?php
	session_start();
?>
<html>

    <head>
        <meta charset="utf-8">
        <title>Kontrola produkcji - Lakiernia</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>SZYBKI START Z BRACKETS</title>
        <link rel="stylesheet" href="bootstrap-4.0.0/dist/css/bootstrap.min.css"">
        <link rel="stylesheet" href="main.css?1">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Dosis&display=swap" rel="stylesheet">
        <link rel="shortcut icon" href="grafika/logo2.png">
        <link rel="stylesheet" type="text/css" href="js/jquery.jqplot.css" />
<!--[if IE]><script language="javascript" type="text/javascript" src="js/excanvas.js"></script><![endif]-->
<script language="javascript" type="text/javascript" src="js/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="js/jquery.jqplot.min.css"></script>
<script language="javascript" type="text/javascript" src="js/jqplot.logAxisRenderer.js"></script>
<script language="javascript" type="text/javascript" src="js/menu.js"></script>
    </head>
    <body >
		<div id="container">
			<div id="pojemnik_menu">
				<div id="pojemnik_logo">
					<ul>
						<li class="logo"><a href="index.html"><img src=grafika/logo.png></a></li>
					</ul>
				</div>
				<div id="pojemnik_kafelki">
					<ul>
						<li class="submenu"><a href="index.html"><span>Overview</span></a></li>
					</ul>
					<div id="pojemnik_menu_rozwijane">
						<ul>
							<li class="submenu"><a href="index.html"><span>Control of Production</span></a></li>
						</ul>
						<ul>
								<li class="submenu"><a href="index.html"><span>Production plan</span></a></li>
								<li class="submenu"><a href="index.html"><span>Production</span></a></li>
								<li class="submenu"><a href="index.html"><span>Product list</span></a></li>
								<li class="submenu"><a href="index.html"><span>BOM List</span></a></li>
								<li class="submenu"><a href="index.html"><span>Route List</span></a></li>							
								<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
						</ul>
					</div>
					<div id="pojemnik_menu_rozwijane2">
						<ul>
							<li class="submenu"><a href="index.html"><span>Quality</span></a></li>
						</ul>
						<ul>
								<li class="submenu"><a href="index.html"><span>Visual Control</span></a></li>
								<li class="submenu"><a href="index.html"><span>SPC</span></a></li>
								<li class="submenu"><a href="index.html"><span>Documentation</span></a></li>
								<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
						</ul>
					</div>
					<div id="pojemnik_menu_rozwijane3">
						<ul>
							<li class="submenu"><a href="index.html"><span>Organization</span></a></li>
						</ul>
						<ul>
								<li class="submenu"><a href="index.html"><span>Organization Chart</span></a></li>
								<li class="submenu"><a href="index.html"><span>Human Resources</span></a></li>
								<li class="submenu"><a href="index.html"><span>Procedures</span></a></li>
								<li class="submenu"><a href="index.html"><span>Forms</span></a></li>
								<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
						</ul>
					</div>
					<div id="pojemnik_menu_rozwijane4">
						<ul>
							<li class="submenu"><a href="index.html"><span>Purchasing & Warehouse</span></a></li>
						</ul>
						<ul>
								<li class="submenu"><a href="index.html"><span>Budget list</span></a></li>
								<li class="submenu"><a href="index.html"><span>Material Warehouse</span></a></li>
								<li class="submenu"><a href="index.html"><span>Supportly Warehouse</span></a></li>
								<li class="submenu"><a href="index.html"><span>Archives</span></a></li>
						</ul>
					</div>
					
					<div id="pojemnik_menu_rozwijane5">
						<ul>
							<li class="submenu"><a href="index.html"><span>System</span></a></li>
						</ul>
						<ul>
								<li class="submenu"><a href="account.php"><span>Account</span></a></li>
								<li class="submenu"><a href="admin.html"><span>Administration</span></a></li>
								<li class="submenu"><a href="index.html"><span>Log out</span></a></li>
						</ul>
					</div>
				</div>
				
			</div>
			<div id="pasek"><img src="grafika/menu.png"/></div>
			<div id="under_top_menu">
		
			<div id="pasek2"><img src="grafika/menu.png"/></div>
			<div class="filters">
			
			chujuuuuu
				<form method="post" role="form" enctype="application/x-www-form-urlencoded">
				
				</form>
			</div>
		
		
		
		</div>
		</div>
		
		
		
            
 			<!--<div class="account_information">
				/*<?php 
				$login = $_SESSION['login'];
				$email = $_SESSION['email'];
				$uprawnienia = $_SESSION['uprawniania'];
				$stanowisko = $_SESSION['stanowisko'];
				$nr_pracownika = $_SESSION['nr_pracownika'];
				$dzial = $_SESSION['dzial'];
				echo<<<END
				<div id="container_account_information">
				<span>Login:<br>$login</span><div class="pasek_pion"></div>
				<span>E-mail:<br> $email</span><div class="pasek_pion"></div>
				<span>Uprawnienia:<br> $uprawnienia</span><div class="pasek_pion"></div>
				<span>Stanowisko:<br> $stanowisko</span><div class="pasek_pion"></div>
				<span>Nr. Pracownika:<br> $nr_pracownika</span><div class="pasek_pion"></div>
				<span>Dział:<br> $dzial</span>>
				</div>
END;
				?>*/
			</div> -->
           <!--  <div id="wynik">
                <table class=" table table-striped table-dark overview">
                        <tr>
                            <th scope="col">OEE: </th>
                            <th id="%oee"scope="col">78%</th>
                            <th scope="col">Quality: </th>
                            <th id="%quality" scope="col">85%</th>
                            <th scope="col">Plan realization: </th>
                            <th id="%planrealization" scope="col">95%</th>
                            <th scope="col">Monthly scrap cost: </th>
                            <th id="%planrealization" scope="col">32000PLN</th>
                        </tr>
                </table>
                <div class="pasek"></div>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Systems</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Waterborn</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>HG</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Matt</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Metalic</th>
                                <th>%</th>
                        </tr>
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Clients</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>BHTC</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Denso</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>MAN</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Seuffer</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>HG</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>MAT</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Panasonic</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Preh</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>BHTC</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>MAN</th>
                                <th>%</th>
                        </tr>
                    </tbody>
                </table>
                <table class=" table table-striped table-dark podzial">
                    <thead>
                        <tr>
                            <th>Metalic</th>
                            <th>%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="wynik_podzial">
                                <th>Seuffer</th>
                                <th>%</th>
                        </tr>
                        <tr class="wynik_podzial">
                                <th>Denso</th>
                                <th>%</th>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        <input type="text" id="liczba" />
        <input type="submit" value="sprawdz" onclick="czas()"/>
       <div id="charts"></div>
    </body>
</html>
-->